# 德国 / 欧盟 VAT 财务速查图册：内容提纲与术语规范

Blue-White VAT Atlas Magazine System v2 · v0.3 术语版 · 2026-05-13

> 本文件为图册策划与文案提纲，不构成税务意见。

## 本版更新
- 章节标题中文优先，“交易性质判断”不再保留德语并列标题。
- 专有名词首次出现必须写中文译名，括号保留德语/英语原文与简称。
- 新增 Glossar 术语表与 tooltip 词库。
- Web 版专有名词采用虚线下划线，hover / focus / tap 显示 tooltip。

## 术语写法原则
首次出现格式：中文译名（德语/英语原文，简称）。例如：欧盟内自有货物调拨（innergemeinschaftliches Verbringen，简称 ig. Verbringen）。

## 章节目录
| 编号 | 章节 / 页面 | 页面类型 | 定位 | 文案重点 |
|---|---|---|---|---|
| 00 | 首页 / 目录页 | Magazine spread 或单页 | 整本图册入口；展示主模块，支持点击 overlay。 | 标题、副标题、阅读方式、图例、8+1 主模块入口。 |
| 01 | VAT 判断总框架 | Decision flow 页 | 建立统一判断顺序，避免直接跳到税率或发票。 | 先判断交易性质，再判断地点、纳税义务、发票、申报和凭证。 |
| 09 | 交易性质判断 | 章节入口页 | 作为所有 B2B 场景之前的基础判断层。 | 一个还是多个给付；货物供应还是服务给付；是否属于特殊拟制交易。 |
| 09-01 | 统一给付 / 单一交易（einheitliche Leistung） | Decision flow 页 | 判断一个整体还是多个独立给付。 | 价值比例不是决定性因素；以普通消费者视角为起点。 |
| 09-02 | 主给付 / 从给付（Hauptleistung / Nebenleistung） | 规则页 | 判断附随元素是否跟随主给付。 | 从给付对客户没有独立目的，通常分享主给付的 VAT 命运。 |
| 09-03 | 工程供货与工程服务边界（Werklieferung / Werkleistung） | 规则页 | 处理材料、加工、维修、安装的边界。 | 先看交易目的和消费者视角，再看材料是否只是辅料或附属材料。 |
| 09-04 | 无偿价值转移与最低计税基础（unentgeltliche Wertabgabe / Mindestbemessungsgrundlage） | 规则 + Case 页 | 处理无偿使用、员工配车、员工福利、关联方低价交易。 | 免费不一定无 VAT；低价不一定按低价计税；核心锚点为 § 3、§ 10 Abs. 4/5 UStG。 |
| 09-05 | 损害赔偿还是对价（Schadensersatz / Entgelt） | 规则页 | 区分真正赔偿与隐藏对价。 | 核心不是合同名称，而是是否存在给付交换。 |
| 09-06 | 委托买卖交易（Kommissionsgeschäft） | 规则页 | 处理委托买卖中 VAT 上的货物供应链条拟制。 | 以自己名义、为他人 Rechnung 的交易需要识别谁被视为供应方 / 接受方。 |
| 09-07 | Case Study：保养、换机油与质保维修 | 案例页 | 用车辆保养案例解释统一给付与消费者视角。 | 单独换机油、保养包、质保期更换发动机、保外付费维修分开讨论。 |
| SC-01 | 德国国内 B2B | 章节入口 + 规则页 | 德国境内供应的默认入口。 | 普通货物、普通服务、税率、§ 13b 例外、发票基本要素。 |
| SC-02 | 欧盟货物交易 | 章节入口 + 流程页 | 处理 DE ↔ EU 货物流。 | 欧盟内免税供应 / 欧盟内购置 / 欧盟内自有货物调拨 / 寄售库存、VAT ID、运输证明、ZM/Intrastat。 |
| SC-03 | 欧盟 B2B 服务 | 章节入口 + 流程页 | 处理跨境服务的给付地点。 | 一般 B2B 服务、特殊服务、不动产、活动、固定机构、客户 VAT ID。 |
| SC-04 | § 13b 反向征税 | 章节入口 + 规则页 | 处理反向征税与 AP/AR 风险。 | 跨境服务、国内建筑/特定行业、发票 wording、ERP tax code。 |
| SC-05 | 进口与出口 | 章节入口 + 清单页 | 处理第三国货物交易与 customs evidence。 | 出口供应、进口 VAT、Incoterms、清关主体、出口凭证。 |
| SC-06 | 连环交易（Reihengeschäft） | Decision flow 页 | 处理多方销售、一次运输。 | 识别有运输归属的供应、运输归属、中间商 VAT ID、免税归属。 |
| SC-07 | 三角贸易（Dreiecksgeschäft） | 规则页 | 处理 EU 三方简化规则。 | 三方不同成员国、VAT ID 条件、中间商发票、最终客户 reverse charge。 |
| SC-08 | 发票与申报 | 矩阵页 | 把 VAT 判断落到可执行动作。 | Invoice wording、UStVA、ZM、Intrastat、E-Rechnung、evidence matrix。 |
| G | Glossar：术语表与 tooltip 词库 | Glossary / data page | 统一中文译名、原文术语、hover tooltip 和首次出现写法。 | 所有专有名词首次出现必须中文译名优先，德语/英语原文在括号或 tooltip 中保留。 |
| A | 附录A：常用货物场景速查 | Appendix quick reference 页 | 从德国公司视角快速判断一般货物 EXW/Abholfall 场景。 | 瑞士客户与意大利客户三组场景；场景描述、税务定性、风险提示。 |

## 章节文案概述
### 00 首页 / 目录页
**定位：** 作为图册入口和 drill-down 导航页，视觉上保持与已确认首页一致：写实、蓝白、现代杂志百科图册风。

**文案方向**
- 主标题：德国 / 欧盟 VAT 财务速查图册
- 副标题：常用 B2B 场景 · 法规提示 · 可点击 Drill-down 导览
- 使用提示：点击对应模块，可通过 overlay 跳转至细节页。
- 阅读方式：先判断交易性质；再判断交易双方与货物流 / 服务流；最后确认发票、申报与凭证要求。

**Drill-down 入口**
- SC-09 交易性质判断
- SC-01 德国国内 B2B
- SC-02 欧盟货物交易
- SC-03 欧盟 B2B 服务
- SC-04 § 13b 反向征税
- SC-05 进口与出口
- SC-06 连环交易
- SC-07 三角贸易
- SC-08 发票与申报

**风险提示**
- 首页文字要少，避免把法律判断写死在图片中。
- overlay 区域以卡片矩形为主，坐标绑定图片版本。

### 01 VAT 判断总框架
**定位：** 给财务人员提供统一的判断顺序，避免从税率或发票 wording 直接开始。

**文案方向**
- 判断顺序：What is supplied? → Where is it supplied? → Who owes VAT? → How to invoice? → How to report? → What evidence is needed?
- 核心提示：VAT 判断的错误往往发生在第一步，即交易本身的“交易性质判断”。
- 页面可设计成从左到右的六步路径，并在每步放置法规锚点。

**Drill-down 入口**
- 交易性质判断
- 给付地点（Leistungsort）
- 纳税义务人（Steuerschuldner）
- Invoice wording
- Reporting
- Evidence

**风险提示**
- 不要把“合同标题”当成 VAT 分类。
- 不要把 Incoterms 当成 VAT 定性的决定因素。

### 09 交易性质判断
**定位：** 新增基础章节，放在普通场景之前，解决工程供货、工程服务、统一给付、无偿价值转移、损害赔偿、委托买卖等问题。

**文案方向**
- 章节导语：很多 VAT 错误不是发生在税率或申报字段，而是发生在更早一步：交易本身到底是什么。
- 先回答：一个给付还是多个给付？货物供应还是服务给付？是否属于特殊视同交易？
- 章节标题不再保留德语名。德语术语统一进入括号或 Glossar / tooltip。

**Drill-down 入口**
- 09-01 统一给付 / 单一交易
- 09-02 主给付 / 从给付
- 09-03 工程供货与工程服务边界
- 09-04 无偿价值转移与最低计税基础
- 09-05 损害赔偿还是对价
- 09-06 委托买卖交易
- 09-07 车辆保养 / 换机油 Case Study

**风险提示**
- 价值比例不是决定性因素。
- invoice line 不是 VAT classification。

### 09-01 统一给付 / 单一交易（einheitliche Leistung）
**定位：** 判断多个组成部分是否为一个统一经济交易。

**文案方向**
- 首次出现写法：统一给付 / 单一交易（einheitliche Leistung）。后文可简称“统一给付”。
- 核心原则：判断统一给付时，不是看哪一项成分金额更高。
- 关键问题：从普通消费者视角（Durchschnittsverbraucher）看，客户购买的是一个整体经济结果，还是多个可以独立消费的主给付（Hauptleistungen）？
- 短句：金额占比可以提示风险，但不能替代交易性质判断。

**Drill-down 入口**
- 普通消费者视角
- 同一供应方要求
- 主给付 / 从给付
- 统一经济交易是否被人为拆分
- 合同/发票形式的非决定性

**风险提示**
- 材料价值 > 人工价值就认定货物供应的机械判断。
- 发票分行列示就拆分多个给付的机械判断。

### 09-02 主给付 / 从给付（Hauptleistung / Nebenleistung）
**定位：** 判断附随元素是否只是帮助客户更好取得主给付。

**文案方向**
- 首次出现写法：主给付 / 从给付（Hauptleistung / Nebenleistung）。
- 从给付通常没有独立经济目的，而是服务于主给付。
- 如果某项元素只是使主给付在更好条件下被取得，通常跟随主给付的 VAT 命运。

**Drill-down 入口**
- 客户是否为该元素本身而购买
- 该元素是否通常伴随主交易出现
- 是否可独立消费
- 是否分享主交易 VAT 命运

**风险提示**
- 把运输、包装、安装、培训、维护等辅助元素机械拆分。

### 09-03 工程供货与工程服务边界（Werklieferung / Werkleistung）
**定位：** 处理材料、加工、维修、安装、客户物品相关的分类。

**文案方向**
- 首次出现写法：工程供货（Werklieferung）与工程服务（Werkleistung）。
- 页面导语：当供应商对客户物品进行加工、维修、安装、改造，并使用自己采购的材料时，需要判断交易更接近货物供应，还是服务给付。
- 判断顺序：普通消费者视角 → 交易经济目的 → 材料是否决定交易本质 → 材料 / 人工价值比例作为辅助线索。
- 不再强调“核心零部件”自动触发边界判断，避免与消费者视角冲突。

**Drill-down 入口**
- 他人物品（fremder Gegenstand）
- 自购材料（selbstbeschaffte Stoffe）
- 辅料 / 附属材料（Zutaten / Nebensachen）
- 消费者取得的是加工后的物还是维修/加工服务
- 价值比例作为辅助指标

**风险提示**
- 看到材料就拆成货物供应 + 服务。
- 看到重大零部件就自动判断为独立货物供应。

### 09-04 无偿价值转移与最低计税基础（unentgeltliche Wertabgabe / Mindestbemessungsgrundlage）
**定位：** 扩展原无偿价值转移页面，覆盖员工配车、员工福利、股东/关联方低价交易以及价格基础调整。

**文案方向**
- 首次出现写法：无偿价值转移（unentgeltliche Wertabgabe）与最低计税基础（Mindestbemessungsgrundlage）。
- 页面标题：免费不一定无 VAT；低价也不一定按低价计税。
- 三层判断：完全无偿 → 检查 § 3 Abs. 1b / § 3 Abs. 9a UStG；有偿但明显低价 → 检查 § 10 Abs. 5 UStG；员工/股东/关联方 → 高风险。
- 员工配车文案：公司车私人使用不是“免费福利就无 VAT”；需检查进项税抵扣（Vorsteuerabzug）、私人使用、实际支付金额与 VAT 计税基础（Bemessungsgrundlage）。

**Drill-down 入口**
- 无偿货物供应（unentgeltliche Lieferung）
- 无偿服务给付（unentgeltliche sonstige Leistung）
- 员工配车 / 私人使用（Firmenwagen / private Nutzung）
- 员工福利（employee benefit）
- 关联方低价交易（related-party low-price transaction）
- 商业收费 vs VAT 计税基础

**风险提示**
- 只做工资税处理，未做 VAT 处理。
- 股东 / 关联方使用公司资产但未检查最低计税基础。
- invoice price 与 VAT taxable base 混淆。

### 09-05 损害赔偿还是对价（Schadensersatz / Entgelt）
**定位：** 区分真正赔偿与隐藏的对价。

**文案方向**
- 首次出现写法：损害赔偿（Schadensersatz）与对价（Entgelt）。
- 页面标题：真正赔偿，还是隐藏的对价？
- 核心不是合同上是否写损害赔偿，而是是否存在给付交换（Leistungsaustausch）。
- 如果付款方取得可识别的经济利益，或收款方作出容忍、放弃或不作为（Duldung / Unterlassen / Verzicht），应进一步判断是否为 taxable consideration。

**Drill-down 入口**
- 真正损害赔偿（echter Schadensersatz）
- 给付交换（Leistungsaustausch）
- 对价减少（Entgeltminderung）
- penalty / cancellation fee
- Duldung / Verzicht

**风险提示**
- 合同写赔偿就直接不征 VAT。
- 把价格调整误作损害赔偿。

### 09-06 委托买卖交易（Kommissionsgeschäft）
**定位：** 解释以自己名义、为他人利益交易时，VAT 上的供应链拟制。

**文案方向**
- 首次出现写法：委托买卖交易（Kommissionsgeschäft）。
- 页面标题：谁在 VAT 上被视为供应方 / 接受方？
- 在销售委托（Verkaufskommission）与采购委托（Einkaufskommission）中，VAT 可能构造委托人（Kommittent）与受托买卖人（Kommissionär）之间的货物供应。
- 页面应强调发票链、货物流和法律拟制可能不同。

**Drill-down 入口**
- 销售委托（Verkaufskommission）
- 采购委托（Einkaufskommission）
- 以自己名义
- 为他人 Rechnung
- 发票链与货物流

**风险提示**
- 只按民法代理关系判断 VAT。
- 忽视受托买卖人在 VAT 链条中的拟制角色。

### 09-07 Case Study：保养、换机油与质保维修
**定位：** 用车辆案例训练“普通消费者视角”和“不按价值比例机械判断”。

**文案方向**
- 问题：车辆保养、换机油、零部件更换，到底是一个给付，还是多个给付？
- 判断原则：不要从零部件价值或技术重要性出发；先问普通消费者理解中，他购买或要求取得的是什么。
- 质保期内更换发动机：消费者通常不是重新购买发动机，而是在要求取得符合合同质量要求的车辆。
- 保外付费更换发动机：才进一步进入工程供货 / 工程服务边界，但仍不能按发动机价值自动下结论。

**Drill-down 入口**
- 单独换机油（Ölwechsel）
- 检查 / 保养（Inspektion / Wartung）包含换机油
- 质保期内补救履行（Nacherfüllung）
- 保外付费维修

**风险提示**
- 按机油金额与人工金额比例机械拆分。
- 看到更换发动机就自动认定独立货物供应。

### SC-01 德国国内 B2B
**定位：** 德国境内 B2B 交易的默认入口。

**文案方向**
- 模块导语：德国境内 B2B 交易通常由德国供应方向德国客户开具含 Umsatzsteuer 的发票；但特定场景可能触发 § 13b UStG。
- 首页短文案：德国境内交易的默认入口：税率、发票、§ 13b 例外。

**Drill-down 入口**
- 普通德国国内货物销售
- 普通德国国内服务
- 国内交易中的 § 13b 例外
- 税率判断：19% / 7% / exempt
- 发票基本要素

**风险提示**
- 国内交易误判为 reverse charge。
- 发票错误列示 VAT。
- 税率适用错误。

### SC-02 欧盟货物交易
**定位：** 处理德国公司与其他 EU Member State 之间的货物流。

**文案方向**
- 模块导语：欧盟内货物交易的核心不是合同签在哪里，而是货物是否实际跨越成员国边境。
- 新增页面：欧盟内自有货物调拨（innergemeinschaftliches Verbringen，简称 ig. Verbringen）；寄售库存 / 备货库存（Konsignationslager / Call-off Stock）。
- 首页短文案：关注货物流是否跨越成员国边境，以及 VAT ID 与运输证明。

**Drill-down 入口**
- DE → EU：欧盟内免税供应（innergemeinschaftliche Lieferung，简称 ig. Lieferung）
- EU → DE：欧盟内购置（innergemeinschaftlicher Erwerb，简称 ig. Erwerb）
- VAT ID 与客户身份校验
- 到货确认 / 运输证明（Gelangensbestätigung / Gelangensnachweis）
- 欧盟内自有货物调拨（ig. Verbringen）
- 寄售库存 / 备货库存（Konsignationslager / § 6b UStG）
- ZM 与 Intrastat 提示

**风险提示**
- 没有有效 VAT ID。
- 货物没有实际跨境运输。
- 运输证明缺失。
- 错把欧盟货物交易当作普通出口。

### SC-03 欧盟 B2B 服务
**定位：** 处理跨境 B2B 服务的给付地点与反向征税。

**文案方向**
- 模块导语：欧盟 B2B 服务的默认规则是客户所在地原则；德国企业向其他欧盟成员国企业提供一般服务时，通常德国不征 VAT，由客户在所在地适用反向征税。
- 首页短文案：一般服务通常看客户所在地，特殊服务需单独判断。

**Drill-down 入口**
- 一般 B2B 服务
- 不动产相关服务
- 活动 / 展会 / 入场服务
- 固定机构 involved 的判断
- 客户 VAT ID 缺失时的处理

**风险提示**
- 服务实际与不动产直接相关。
- 客户 VAT ID 无效。
- 固定机构参与交易但未识别。
- 发票误列德国 VAT。

### SC-04 § 13b 反向征税
**定位：** 处理接受方纳税义务与 AP/AR 风险。

**文案方向**
- 模块导语：在特定交易中，VAT 不由供应商缴纳，而由客户作为接受方（Leistungsempfänger）承担纳税义务。
- 首页短文案：税负从供应商转移给客户，AP 与 invoice wording 是关键。

**Drill-down 入口**
- 德国企业收到 EU 服务
- 德国企业收到第三国服务
- 德国国内建筑服务
- 特定货物 / 行业 reverse charge
- Reverse charge invoice wording

**风险提示**
- 供应商误开发票含 VAT。
- 客户没有自我计税。
- AP 入账未识别 reverse charge。
- SAP tax code 选择错误。

### SC-05 进口与出口
**定位：** 处理第三国货物交易中的 VAT 与 customs。

**文案方向**
- 模块导语：第三国交易需要同时考虑 VAT 与 customs；出口关注免税条件与凭证，进口关注 import VAT、清关主体和 input VAT deduction。
- 首页短文案：第三国交易同时涉及 VAT、customs、Incoterms 与凭证链。

**Drill-down 入口**
- 德国出口至第三国：出口供应（Ausfuhrlieferung）
- 第三国进口至德国
- Import VAT 抵扣
- Incoterms 与清关主体
- 出口凭证与 customs evidence

**风险提示**
- 出口免税凭证不足。
- 清关主体与发票主体不一致。
- Import VAT deduction 主体错误。

### SC-06 连环交易（Reihengeschäft）
**定位：** 处理多方销售但只有一次实际运输的场景。

**文案方向**
- 模块导语：连环交易的核心是识别哪一笔供应是有运输归属的供应（bewegte Lieferung），其他供应则为非移动供应（ruhende Lieferung）。
- 首页短文案：多笔销售、一次运输，核心是识别有运输归属的供应。

**Drill-down 入口**
- 三方连环交易基础结构
- 第一方安排运输
- 中间商安排运输
- 最终客户安排运输
- VAT ID 与运输归属判断

**风险提示**
- 合同流、发票流、物流混淆。
- 错误识别有运输归属的供应。
- 中间商 VAT ID 使用错误。

### SC-07 三角贸易（Dreiecksgeschäft）
**定位：** 处理欧盟内部三方交易简化规则。

**文案方向**
- 模块导语：三角贸易是欧盟内部连环交易中的一种简化规则；满足条件时，中间商可避免在到货国注册 VAT。
- 首页短文案：欧盟三方交易简化规则，条件失败时风险较高。

**Drill-down 入口**
- 标准 EU triangular transaction
- 三方 VAT ID 条件
- 中间商发票要求
- 最终客户 reverse charge
- 简化规则失败情形

**风险提示**
- 三方不在不同成员国。
- 中间商使用错误 VAT ID。
- 发票没有三角贸易提示。

### SC-08 发票与申报
**定位：** 把判断结果转化为 invoice、UStVA、ZM、Intrastat 和 evidence 动作。

**文案方向**
- 模块导语：VAT 判断最终必须落到发票、账务处理、申报与凭证留存。
- 首页短文案：VAT 判断最终落到 invoice、UStVA、ZM、Intrastat 与 evidence。

**Drill-down 入口**
- 普通德国 VAT 发票
- Reverse charge 发票
- Intra-EU supply 发票
- Export invoice
- UStVA / ZM / Intrastat / customs matrix
- E-Rechnung 提示

**风险提示**
- 发票 wording 与 VAT treatment 不一致。
- ZM 漏报或 VAT ID 错误。
- 凭证留存不足。

### 附录A：常用货物场景速查
**定位：** 从德国公司视角，为一般货物（非车辆）EXW / Abholfall 场景提供速查。可作为图片形式补充，也可在 Web 版用 HTML 表格叠加在统一风格背景上。

**文案方向**
- 适用范围：德国公司作为供应商；一般货物，非车辆；不覆盖新交通工具、安装供应、消费税货物、特殊监管货物。
- 基础提示：Incoterms 不是 VAT 定性的决定因素。EXW 只说明商业交付安排，不自动决定是否出口供应、欧盟内免税供应或连环交易。
- EU / EWR / Switzerland 速记：EWR 不等于 EU VAT area；Switzerland 不属于 EU，也不属于 EWR；Schengen 不等于 EU VAT area。

**Drill-down 入口**
- CH-01 瑞士客户德国取货送瑞士
- CH-02 瑞士客户德国取货直接发法国
- CH-03 瑞士客户德国取货中转瑞士后发法国
- IT-01 意大利客户德国取货送意大利
- IT-02 意大利客户德国取货直接发法国
- IT-03 意大利客户德国取货中转意大利后发法国

**风险提示**
- 只看 EXW，不看实际货物流。
- Swiss VAT number 被误当作 EU VAT ID。
- 客户使用 German USt-IdNr. 却仍按 EU supply 免税开票。
- 缺少出口证明 / 到货证明 / ZM 一致性。

## Glossar：术语表与 tooltip 词库
| ID | 中文译名 | 原文术语 | 首次出现写法 | Tooltip | 关联章节 |
|---|---|---|---|---|---|
| leistung | 给付 / 交易标的 | Leistung | 给付 / 交易标的（Leistung） | VAT 分析中的基础概念，指供应方提供的货物供应或服务给付。 | 01, 09 |
| lieferung | 货物供应 | Lieferung | 货物供应（Lieferung） | 通常指转移对有形货物处分权的供应。 | 09, SC-02 |
| sonstigeLeistung | 服务给付 / 其他给付 | sonstige Leistung | 服务给付 / 其他给付（sonstige Leistung） | 不属于货物供应的其他 VAT 给付类型。 | 09, SC-03 |
| einheitlicheLeistung | 统一给付 / 单一交易 | einheitliche Leistung | 统一给付 / 单一交易（einheitliche Leistung） | 多个元素从普通消费者视角构成一个整体经济交易时，通常按一个给付判断。 | 09-01 |
| durchschnittsverbraucher | 普通消费者视角 | Durchschnittsverbraucher | 普通消费者视角（Durchschnittsverbraucher） | 从一般消费者对交易本质的理解出发，而不是机械看合同标题、发票行或价值比例。 | 09-01 |
| hauptleistung | 主给付 | Hauptleistung | 主给付（Hauptleistung） | 客户真正追求的主要经济结果。 | 09-02 |
| nebenleistung | 从给付 / 附随给付 | Nebenleistung | 从给付 / 附随给付（Nebenleistung） | 对客户没有独立目的，只是帮助客户更好取得主给付的元素。 | 09-02 |
| werklieferung | 工程供货 | Werklieferung | 工程供货（Werklieferung） | 含加工/安装/改造并使用供应方材料的交易，若本质更接近交付加工后的物，可能按货物供应处理。 | 09-03 |
| werkleistung | 工程服务 | Werkleistung | 工程服务（Werkleistung） | 含加工/维修/安装的交易，若材料仅为辅料或本质更接近服务成果，可能按服务给付处理。 | 09-03 |
| unentgeltlicheWertabgabe | 无偿价值转移 | unentgeltliche Wertabgabe | 无偿价值转移（unentgeltliche Wertabgabe） | 企业资产或服务被无偿用于私人、员工或非企业目的时，可能被视同有偿交易。 | 09-04 |
| mindestbemessungsgrundlage | 最低计税基础 | Mindestbemessungsgrundlage | 最低计税基础（Mindestbemessungsgrundlage） | 在员工、股东、关联方等低价交易中，VAT 计税基础可能需要提高到法定最低基础。 | 09-04 |
| bemessungsgrundlage | 计税基础 | Bemessungsgrundlage | 计税基础（Bemessungsgrundlage） | 计算 VAT 的基础金额。 | 09-04 |
| firmenwagen | 员工 / 公司配车 | Firmenwagen | 员工 / 公司配车（Firmenwagen） | 公司车如允许私人使用，VAT 上需检查进项税抵扣、私人使用和计税基础。 | 09-04 |
| schadensersatz | 损害赔偿 | Schadensersatz | 损害赔偿（Schadensersatz） | 只有缺少给付交换时才更接近真正赔偿；合同名称本身不决定 VAT 处理。 | 09-05 |
| leistungsaustausch | 给付交换 | Leistungsaustausch | 给付交换（Leistungsaustausch） | 一方取得可识别经济利益且另一方取得对价时，通常需要进入 VAT 应税分析。 | 09-05 |
| entgelt | 对价 | Entgelt | 对价（Entgelt） | 为取得货物供应或服务给付而支付或应支付的金额或经济利益。 | 09-05 |
| kommissionsgeschaeft | 委托买卖交易 | Kommissionsgeschäft | 委托买卖交易（Kommissionsgeschäft） | 以自己名义、为他人利益交易时，VAT 可拟制委托人与受托买卖人之间的供应链。 | 09-06 |
| igLieferung | 欧盟内免税供应 | innergemeinschaftliche Lieferung / ig. Lieferung | 欧盟内免税供应（innergemeinschaftliche Lieferung，简称 ig. Lieferung） | 货物从德国运往另一 EU 成员国且满足条件时，德国出发端可能免 VAT。 | SC-02, A |
| igErwerb | 欧盟内购置 | innergemeinschaftlicher Erwerb / ig. Erwerb | 欧盟内购置（innergemeinschaftlicher Erwerb，简称 ig. Erwerb） | 企业从其他 EU 成员国取得跨境货物时，在到货国通常需要识别 EU acquisition。 | SC-02 |
| igVerbringen | 欧盟内自有货物调拨 | innergemeinschaftliches Verbringen / ig. Verbringen | 欧盟内自有货物调拨（innergemeinschaftliches Verbringen，简称 ig. Verbringen） | 同一企业将自有货物从一个 EU 成员国调至另一成员国，VAT 上可能被视同供应/购置。 | SC-02 |
| konsignationslager | 寄售库存 / 备货库存 | Konsignationslager / Call-off Stock | 寄售库存 / 备货库存（Konsignationslager / Call-off Stock） | 供应商将货物预先放入客户所在国库存，满足条件时可适用 call-off stock 简化规则。 | SC-02 |
| reihengeschaeft | 连环交易 | Reihengeschäft / chain supply | 连环交易（Reihengeschäft / chain supply） | 多方连续买卖但只有一次实际运输，需要判断哪一笔供应获得运输归属。 | SC-06, A |
| bewegteLieferung | 有运输归属的供应 / 移动供应 | bewegte Lieferung | 有运输归属的供应（bewegte Lieferung） | 在连环交易中，被分配到实际运输的那一笔供应。 | SC-06 |
| ruhendeLieferung | 非移动供应 | ruhende Lieferung | 非移动供应（ruhende Lieferung） | 连环交易中未被分配到实际运输的其他供应。 | SC-06 |
| dreiecksgeschaeft | 三角贸易 | Dreiecksgeschäft | 三角贸易（Dreiecksgeschäft） | EU 内部三方交易简化规则，满足条件时中间商可避免在到货国注册 VAT。 | SC-07 |
| ausfuhrlieferung | 出口供应 | Ausfuhrlieferung | 出口供应（Ausfuhrlieferung） | 货物从德国/EU 出口至第三国并满足证明要求时，可能免德国 VAT。 | SC-05, A |
| abholfall | 客户自提情形 | Abholfall | 客户自提情形（Abholfall） | 客户或其受托方在德国取货并自行安排运输的场景，免税高度依赖证明。 | A |
| gelangensnachweis | 到货证明 / 到货确认 | Gelangensnachweis / Gelangensbestätigung | 到货证明 / 到货确认（Gelangensnachweis / Gelangensbestätigung） | 用于证明 EU 内货物实际到达另一成员国的文件或证据组合。 | SC-02, A |
| zm | 欧盟交易汇总申报 | Zusammenfassende Meldung / ZM | 欧盟交易汇总申报（Zusammenfassende Meldung，简称 ZM） | 德国供应商对特定 EU 交易进行的汇总申报。 | SC-02, SC-08, A |
| ustva | 德国 VAT 预申报 | Umsatzsteuer-Voranmeldung / UStVA | 德国 VAT 预申报（Umsatzsteuer-Voranmeldung，简称 UStVA） | 德国 Umsatzsteuer 的周期性预申报。 | SC-08 |
| ustIdNr | 德国 / 欧盟 VAT 识别号 | USt-IdNr. / VAT ID | 德国 / 欧盟 VAT 识别号（USt-IdNr. / VAT ID） | 用于识别 EU VAT taxable person 的税号；Swiss VAT number 不能替代 EU VAT ID。 | SC-02, A |
| exw | 工厂交货 | EXW / Ex Works | 工厂交货（EXW / Ex Works） | Incoterms 交货条件之一；不自动决定 VAT 定性或免税。 | A |
| ewr | 欧洲经济区 | EWR / EEA | 欧洲经济区（EWR / EEA） | 包括 EU、Iceland、Liechtenstein、Norway；EWR 不等于 EU VAT area。 | A, G |

## Tooltip / hover 技术规范
专有名词使用 `<span class="term" data-term="igVerbringen">欧盟内自有货物调拨</span>` 或 React `<Term id="igVerbringen">欧盟内自有货物调拨</Term>`。桌面端 hover/focus 显示 tooltip，移动端 tap 显示。

## 附录A：常用货物场景速查表
| 编号 | 场景描述 | 税务定性 | 风险提示 |
|---|---|---|---|
| CH-01 | 瑞士客户 EXW 在德国取货，送到瑞士 | 通常为出口供应（Ausfuhrlieferung） | 关键看货物是否实际离开 EU 并进入瑞士；需出口证明；EXW 本身不自动免德国 VAT。 |
| CH-02 | 瑞士客户 EXW 在德国取货，直接发到法国 | 通常属于连环交易（chain supply / Reihengeschäft）；可能是欧盟内免税供应，也可能是德国境内应税供应 | 取决于瑞士客户使用哪个税号。使用非德国 EU VAT ID 时，DE→CH 可能免税；只用 Swiss VAT number 或使用 German USt-IdNr. 时风险高。 |
| CH-03 | 瑞士客户 EXW 在德国取货，中转瑞士后再发到法国 | 瑞士是真实第一目的地时，DE→CH 可按出口供应判断；瑞士只是中转时，应回到 DE→FR 连环交易 / EU goods movement 分析 | “经过瑞士”不等于“出口到瑞士”；需证明瑞士是否为第一段真实目的地，以及运输是否连续。 |
| IT-01 | 意大利客户 EXW 在德国取货，送到意大利 | 通常为欧盟内免税供应（innergemeinschaftliche Lieferung） | 需要有效 Italian VAT ID、货物实际到达意大利的证明，以及 ZM 申报。 |
| IT-02 | 意大利客户 EXW 在德国取货，直接发到法国 | 通常属于 EU 连环交易；可能为免税 EU supply，也可能是德国境内应税供应 | 关键看意大利客户使用哪个税号。使用非德国 EU VAT ID 时，DE→IT 可能免税；若使用 German USt-IdNr.，DE→IT 往往变成德国境内应税供应。 |
| IT-03 | 意大利客户 EXW 在德国取货，中转意大利后再发到法国 | 意大利是真实第一目的地时，DE→IT 通常是 Germany→Italy 的欧盟内免税供应；意大利只是中转时，应回到 DE→FR 连环交易分析 | 临时中转仓不自动改变 VAT treatment；需证明意大利是否为第一段真实目的地。 |

## 法规锚点与来源索引
- **UStG § 3** — 货物供应、服务给付；含工程供货、委托买卖、无偿价值转移等基础概念。 — https://www.gesetze-im-internet.de/ustg_1980/__3.html
- **UStG § 3a** — 服务给付地点；跨境服务地点判断。 — https://www.gesetze-im-internet.de/ustg_1980/__3a.html
- **UStG § 6** — 出口供应（Ausfuhrlieferung）。 — https://www.gesetze-im-internet.de/ustg_1980/__6.html
- **UStG § 6a** — 欧盟内免税供应（innergemeinschaftliche Lieferung）。 — https://www.gesetze-im-internet.de/ustg_1980/__6a.html
- **UStG § 6b** — 寄售库存 / 备货库存简化规则（Konsignationslager / Call-off stock）。 — https://www.gesetze-im-internet.de/ustg_1980/__6b.html
- **UStG § 10** — 计税基础；§ 10 Abs. 4/5 与最低计税基础。 — https://www.gesetze-im-internet.de/ustg_1980/__10.html
- **UStG § 13b** — 接受方纳税义务 / 反向征税。 — https://www.gesetze-im-internet.de/ustg_1980/__13b.html
- **UStG § 14** — 发票。 — https://www.gesetze-im-internet.de/ustg_1980/__14.html
- **UStG § 25b** — 欧盟内三角贸易。 — https://www.gesetze-im-internet.de/ustg_1980/__25b.html
- **UStAE 3.10** — 统一给付；普通消费者视角与多个/单一给付判断。 — https://usth.bundesfinanzministerium.de/usth/2023/A-Umsatzsteuergesetz/I-Steuergegenstand-und-Geltungsbereich/Paragraf-3/ae-3-10.html
- **UStAE 3.8** — 工程供货与工程服务边界。 — https://usth.bundesfinanzministerium.de/usth/2023/A-Umsatzsteuergesetz/I-Steuergegenstand-und-Geltungsbereich/Paragraf-3/ae-3-8.html
- **UStAE 10.7** — 最低计税基础；员工/股东/关联方交易。 — https://usth.bundesfinanzministerium.de/usth/2024/A-Umsatzsteuergesetz/III-Bemessungsgrundlagen/Paragraf-10/inhalt.html
- **EU Commission VAT place of taxation** — B2B service place of taxation normally follows customer establishment, Article 44 VAT Directive。 — https://taxation-customs.ec.europa.eu/taxation/vat/vat-directive/place-taxation_en