# Tooltip / Glossar Implementation

## Data source

Use `VAT_Atlas_Glossary_CN.json` as the single source of truth for term labels and tooltips.

## React component

```tsx
type TermProps = { id: string; children: React.ReactNode };

export function Term({ id, children }: TermProps) {
  const item = glossaryById[id];

  return (
    <span
      className="term"
      tabIndex={0}
      role="button"
      aria-label={item ? `${item.zh}: ${item.tooltip}` : undefined}
      data-term={id}
      data-tooltip={item?.tooltip}
    >
      {children}
    </span>
  );
}
```

## CSS

```css
.term {
  border-bottom: 1px dashed #1457A8;
  color: #0B2A5B;
  cursor: help;
  text-decoration: none;
  text-underline-offset: 3px;
}

.term:hover,
.term:focus {
  background: rgba(20, 87, 168, 0.08);
  outline: none;
}

.term-tooltip {
  max-width: 320px;
  padding: 8px 10px;
  border-radius: 8px;
  background: #0B2A5B;
  color: white;
  font-size: 13px;
  line-height: 1.45;
  box-shadow: 0 10px 30px rgba(11, 42, 91, 0.25);
  z-index: 50;
}
```

## Copy rule

First occurrence: Chinese translation first, original term in parentheses.

Example: `欧盟内自有货物调拨（innergemeinschaftliches Verbringen，简称 ig. Verbringen）`.

Later occurrences may use the Chinese label wrapped by `<Term id="igVerbringen">欧盟内自有货物调拨</Term>`.
