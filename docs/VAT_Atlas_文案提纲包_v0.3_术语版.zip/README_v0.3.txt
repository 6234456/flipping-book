VAT Atlas Content Package v0.3
================================

文件清单：
1. VAT_Atlas_Content_Outline_CN_v0.3_术语版.docx
   - 主文档：章节目录、文案概述、术语写法原则、Glossar、tooltip 技术规范、附录A速查表、法规锚点索引。

2. VAT_Atlas_Content_Outline_CN_v0.3_术语版.md
   - Markdown 版本，便于后续导入知识库、CMS 或交给开发生成页面。

3. VAT_Atlas_Glossary_CN.json
   - 术语 tooltip 数据源。

4. Tooltip_Overlay_Implementation.md
   - Web 端虚线下划线和 hover / tap tooltip 的实现建议。

说明：
- 本版将章节标题改为中文优先；“交易性质判断”不再保留德语并列标题。
- 专有名词首次出现必须有中文译名，德语/英语术语放入括号、Glossar 或 tooltip。
- 本资料包是内容策划与文案提纲，不构成德国/欧盟 VAT 税务意见。

Draft date: 2026-05-13
